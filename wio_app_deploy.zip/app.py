from flask import Flask, render_template, request, redirect, url_for, flash
import uuid
import datetime
from collections import defaultdict

app = Flask(__name__)
app.secret_key = 'secret123'  # For flashing messages

# --- Backend Logic (WioAICareSystem and Citizen) ---

class Citizen:
    def __init__(self, umn, name, dob_str, contact_info="N/A"):
        self.umn = umn
        self.name = name
        try:
            self.dob = datetime.datetime.strptime(dob_str, "%Y-%m-%d").date()
        except ValueError:
            raise ValueError("DOB must be in YYYY-MM-DD format")
        self.contact_info = contact_info
        self.medical_records = []
        self.prescriptions = []

class WioAICareSystem:
    def __init__(self):
        self.citizens_data = {}

    def generate_umn(self):
        return str(uuid.uuid4())

    def register_citizen(self, name, dob_str, contact_info="N/A"):
        umn = self.generate_umn()
        try:
            citizen = Citizen(umn, name, dob_str, contact_info)
            self.citizens_data[umn] = citizen
            return umn
        except ValueError as e:
            return None

    def get_citizen(self, umn):
        return self.citizens_data.get(umn)

    def summarize_citizen_medical_data(self, umn):
        citizen = self.get_citizen(umn)
        if not citizen:
            return "Citizen not found."

        summary = f"Name: {citizen.name}\nUMN: {umn}\nDOB: {citizen.dob}\nContact: {citizen.contact_info}\n"
        summary += f"Medical Records: {len(citizen.medical_records)}\n"
        summary += f"Prescriptions: {len(citizen.prescriptions)}\n"
        return summary

system = WioAICareSystem()

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        dob = request.form['dob']
        contact = request.form['contact']
        umn = system.register_citizen(name, dob, contact)
        if umn:
            flash(f"Citizen registered with UMN: {umn}", 'success')
            return redirect(url_for('index'))
        else:
            flash("Registration failed. Invalid data.", 'danger')
    return render_template('register.html')

@app.route('/summary', methods=['GET'])
def summary():
    umn = request.args.get('umn')
    if not umn:
        flash("UMN not provided", 'warning')
        return redirect(url_for('index'))
    summary = system.summarize_citizen_medical_data(umn)
    return render_template('summary.html', summary=summary)

if __name__ == '__main__':
    app.run(debug=True)
